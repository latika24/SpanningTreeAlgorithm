# include <iostream>
# include <vector>
# include <set>
# include <queue>
# include <string>
# include "bridgesim.h" 
using namespace std;
